# Calibration reuse follow-up: proof-and-evidence package

This package develops a **potentially original, not priority-verified** characterization of ordinary positive-temperature softmax LAC. It is not a conference submission draft and does not claim a practical improvement over existing valid selection methods.

Start with:

- `EVIDENCE.md` — findings, actual results, scope, and reviewer assessment.
- `PROOFS.md` — full assumptions and arguments, including the local realization lemma, VC bound, reuse upper bound, and explicit coverage-loss law.
- `PRIOR_WORK.md` — four candidates, closest works, novelty objections, current revisions, and data-access status.
- `CLAIM_EVIDENCE.csv` — each main claim mapped to proof/code/data and its limitations.

## Reproduce the checks

Python 3.13.5 was used. No GPU, model, model API, data download, or paid cloud job is required. NumPy, SciPy, SymPy and mpmath are the only scientific dependencies. A 16 GB machine is far above the measured memory requirement, but the reported timings are from a hosted CPU rather than a laptop.

```bash
python -m venv .venv
# Linux/macOS:
source .venv/bin/activate
# Windows PowerShell instead: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
python verify_manifest.py
python source/verify_integer_witnesses.py
python source/interpolation_certificate.py
python source/coverage_embedding.py
python tests/test_research.py
```

The numerical commands regenerate outputs in `results/`. Resource-time fields will change, so run `verify_manifest.py` BEFORE regeneration for a byte-level archive-integrity check, or use it on a fresh extracted copy. Tests reconstruct the statistical summaries and exact certificates, which are the substantive reproducibility checks.

To repeat the original EXPLORATORY float search separately:

```bash
python source/search_witness.py
python source/verify_integer_witnesses.py
```

The search is not the proof. Floating-point ties can create false witnesses: the saved K=4 candidate is one such documented failure. Different floating-point environments can change exploratory search choices. The exact certificate files, symbolic arguments, and calibration simulation are the evidence.

## Protocol chronology

`protocol.json` was saved before the initial numerical search. It was not changed after the K=4 witness failed exact checking. `coverage_extension_protocol.json` was then written, explicitly labelled as a subsequent theory-driven extension, before the softmax coverage simulation. Neither protocol was registered with an independent timestamping service. SHA files check that the saved protocol bytes remain unchanged; they do not constitute external preregistration. Source-code hashes are closeout provenance, not claimed pre-execution commitments.

## Important interpretation

The actual softmax experiment has K=3, two candidate inverse temperatures, and an adversarial minimum-normalized-quantile selector. It does NOT test a claim that negative-log-likelihood tuning fails. The NLL grid control is valid here. The larger-M table samples the exact Beta order-statistic law; it is NOT reported as a numerical inverse-softmax experiment for every M.

The worst-case result is for unmodified split-style calibration AFTER selecting a temperature on the same observations. Exact full-conformal/ModSel methods are outside that impossibility construction and are acknowledged prior alternatives. Empty LAC sets are allowed.

## Files and provenance

The original attached audit was read, not overwritten. Its zip SHA-256 is `54d76944f136993b5a8594972d1dddabd885af2ff8d266c88c8ae5329b1f0ff1`.

Raw conditional-coverage replications are in `results/coverage_raw.npz`. `results/*_timing.txt` preserve `/usr/bin/time -v` output for all five recorded research commands. Hardware and dependency versions are in `results/environment.json`. Exact rational witnesses, the rejected float case, interpolation certificates, and test logs are retained.

No copyrighted paper PDFs or external logits are redistributed in this package.
