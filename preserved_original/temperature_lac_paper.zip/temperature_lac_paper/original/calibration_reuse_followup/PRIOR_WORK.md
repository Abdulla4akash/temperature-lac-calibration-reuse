# Candidate comparison and prior-work audit

**Checked 30 September 2026.** The search establishes concrete overlap with the named sources below. It does not establish publication priority for the new proof candidate. Several broad searches returned irrelevant results; these were not treated as evidence of absence. OpenReview's discussion for Zeng et al. was blocked by browser verification. No authors were contacted.

## Candidate table

| Candidate | Closest prior results | Precise proposed advance | Why nontrivial | Why useful | Cheapest decisive test | Compute requirement (estimate before execution) | Main failure risk / verdict |
|---|---|---|---|---|---|---|---|
| A. Observable stability certificate for reuse | Ndiaye 2022; Lee–Zhang 2025; Hegazy et al. 2025 | A calibration-only certificate for the change in score ranks after adding a test example, without an unavailable global stability constant | A statistic observable on calibration data must control unseen perturbations | Could avoid unnecessary splitting and excessive correction | Reduce it to existing stability results; attack with unseen-category examples | Symbolic analysis; seconds/minutes for finite counterexamples; <1 GB | Generic proposal is already covered by stability methodology. No new observable certificate was obtained. Discard the generic claim. |
| B. Cheap exact-valid temperature/model selection | Yang–Kuchibhotla 2024; Liang–Zhu–Barber v4 2026; Wang–Wang 2026 | Certified screening/batching giving exact validity and demonstrably less computation than the existing constructions | Must prove screening cannot remove a selected candidate for any possible test label | More calibration observations without a major runtime penalty | Compare exact augmented-data selection with ModSel-CP/LOO and current safe-index methods | Minutes for a small fixed-grid implementation; <1 GB | Full-conformal symmetry and candidate screening are not new by themselves. No new complexity reduction or empirical advantage was established. Discard generic “exact reuse” novelty. |
| C. Temperature-scaled LAC complexity and worst-case coverage loss | Zeng et al. 2025; Yang–Kuchibhotla 2024; Dabah–Tirer 2025; additionally Mattei–Loureiro v2 2026 | A softmax-specific sharp leading-order VC characterization, a continuum reuse upper bound, and an explicit finite-family realization giving a genuine coverage lower example | Positive exponential sums have constrained crossings; a lower complexity claim must be embedded inside actual softmax, and then connected to the conformal quantile | Replaces an invalid dimension-only argument; supplies rigorous stress tests and a precise target for sharper algorithm-specific guarantees | Exact score-order witnesses; prove local realization; compare the actual softmax pipeline with the resulting order-statistic law | Seconds to minutes for checks; no external dataset required | Mathematical evidence survived. Priority and practical significance remain unresolved. No NLL-failure or superior-method claim. |
| D. Released-logit efficiency/coverage re-evaluation | Dabah–Tirer 2025; Zeng et al. 2025; Liang–Zhu–Barber v4 2026 | A previously unrecognized reversal of a model/method recommendation after honest selection and final calibration | Must distinguish a genuine changed conclusion from already-known adaptive selection bias | Could change a benchmark recommendation | Verify saved logits, freeze development/evaluation split, then compare the published procedure and competent valid-selection baselines | Estimated <1 CPU-hour pilot; <8 CPU-hours bounded suite; <2 GB | Released files verified at metadata level, not loaded or analyzed. Generic reuse failure is already known; no distinct empirical hypothesis survived strongly enough to launch. |

**Development priority:** C first; B second for practical value but no established new idea; A third because the proposed novelty requires an unavailable certificate; D fourth because a distinct empirical conclusion-change hypothesis is not yet established. These are judgments about THIS set of proposed contributions, not rankings of the prior papers.

## A. Three closest stability results

1. **Eugene Ndiaye, Stable Conformal Prediction Sets, ICML 2022.** https://proceedings.mlr.press/v162/ndiaye22a.html . Uses algorithmic-stability bounds to approximate otherwise expensive full-conformal construction without losing coverage or requiring ordinary sample splitting. Applicable stability control is an assumption/resource, not automatically an observable certificate.
2. **Kiljae Lee and Yuan Zhang, Leave-One-Out Stable Conformal Prediction, ICLR 2025.** https://arxiv.org/abs/2504.12189 . Develops leave-one-out rather than replace-one stability to make multiple prediction requests efficient, with bounds for several learning procedures. A generic “one fit plus stability” proposal does not advance beyond this.
3. **Hegazy, Aolaritei, Jordan, Dieuleveut, Valid Selection among Conformal Sets, 2025.** https://arxiv.org/html/2506.20173v1 . Uses a stable selector relative to a data-independent reference, including randomized selection, to control post-selection error. The proposed generic randomized/stability tuning mechanism would overlap directly.

**Missing addition:** a provably valid, materially less conservative certificate computable from the observed calibration sample. We did not obtain one. Applying an existing stability theorem is not claimed as a contribution.

## B. Three closest selection results

1. **Yachong Yang and Arun Kumar Kuchibhotla, Selection and Aggregation of Conformal Prediction Sets, v3 April 2024.** https://arxiv.org/html/2104.13871v3 . A finite fixed family can be searched directly with a quantified coverage penalty; a split selection/calibration alternative restores finite-sample validity with an efficiency comparison. The relevant family-size penalty already has square-root-log-family behavior.
2. **Ruiting Liang, Wanrong Zhu, Rina Foygel Barber, Conformal prediction after data-dependent model selection, v4 16 April 2026.** https://arxiv.org/html/2408.07066v4 . ModSel-CP and its leave-one-out variant use full-conformal symmetry for exact marginal validity without an extra split. Efficiency guarantees require their stated regularity conditions. This is the essential comparison for any claimed new exact reuse method.
3. **Yuhao Wang and Tengyao Wang, Localized conformal model selection, 22 February 2026.** https://arxiv.org/abs/2602.19284 . Symmetric local selection constructs a safe index set and retains exact marginal coverage in its proposed ensemble framework. Merely proposing a safe candidate set is insufficient novelty.

**Missing addition:** a new, proved computational reduction or a fair, measured improvement in set efficiency/runtime. Neither was established. No experiment against these methods is falsely reported.

## C. Closest results and the precise possible advance

1. **Zeng, Liu, Jing, Wei, Parametric Scaling Law of Tuning Bias in Conformal Prediction, ICML 2025.** https://proceedings.mlr.press/v267/zeng25e.html ; inspected https://arxiv.org/html/2502.03023v2 (10 July 2025). Its valid empirical-process reduction and binary invariance are acknowledged. The new candidate concerns actual multiclass softmax complexity and a coverage construction within that family, rather than another abstract scalar counterexample.
2. **Yang–Kuchibhotla, above.** Finite-family selection penalties are known. The proposed addition is NOT another finite-family bound: it is the realization of K-1 locally independent score coordinates inside one fixed K-class softmax temperature family, paired with a bound on the whole continuum.
3. **Lahav Dabah and Tom Tirer, On Temperature Scaling and Conformal Prediction of Deep Classifiers, ICML 2025.** https://arxiv.org/html/2402.05806v3 . Investigates temperature/conformal set-size and class-conditional-coverage trade-offs, especially APS/RAPS. It does not establish the particular LAC realization/VC/coverage characterization proposed here in the inspected text.

**Additional current revision checked:** Pierre-Alexandre Mattei and Bruno Loureiro, The Well-Tempered Classifier: Some Elementary Properties of Temperature Scaling, v2 27 May 2026, https://arxiv.org/html/2602.14862v2 . Its entropy, likelihood and accuracy-preservation results are not claimed here. Within-example class-order preservation must not be confused with cross-example score-order preservation.

**Foundational overlap checked:** Goldberg and Jerrum, Bounding the Vapnik-Chervonenkis Dimension of Concept Classes Parameterized by Real Numbers, COLT 1993, https://doi.org/10.1145/168304.168377 . General syntactic-complexity VC methods are older. Counting curve crossings and using an inverse-function/Vandermonde argument are classical tools. Their use alone does not establish priority.

**Who benefits:** researchers proving guarantees for temperature-adjusted conformal procedures, and developers needing very small test cases for overly broad reuse claims. A practical deployment recommendation is not justified by an unspecified-constant worst-case rate.

**Strongest novelty objection:** the upper bound is a specialized arrangement argument, the lower embedding uses standard local inversion, and finite-family selection bias is already known. An existing parametric-family or calibration paper could subsume the combination. The exact three-part statement deserves expert comparison; keyword absence is not sufficient.

## D. Data verification and why no real-data claim is made

The authors' repository is https://github.com/lahavdabah/TS4CP . The connected GitHub action fetched its README and the `data/` directory. The README specifies `.npz` arrays named `logits` and `labels`. Metadata verified these files:

| Released file | Bytes | Git blob SHA |
|---|---:|---|
| Cifar10-ResNet34_data.npz | 480510 | 59e9324c2e7e894cc5280b5b103ef9bb41d1dc4c |
| Cifar10-ResNet50_data.npz | 480510 | 767d3745c85d28eec95aa4e9e4d3ab24ee5bb9ba |
| Cifar100-DenseNet121_data.npz | 4080510 | 433160fa21a50ef94933e91e4360955d9947a9c5 |
| Cifar100-ResNet50_data.npz | 4080510 | a21f3cd4e72f18815273d85e5e4a8c5c65897e16 |

This verifies released-file existence, NOT successful local loading, data quality, licensing for redistribution, split independence, or any scientific outcome. Binary files were not retrieved through the text-only connector, no inference was run, and no real-data experiment is reported. The three closest empirical/procedural comparisons are Dabah–Tirer, Zeng et al., and Liang–Zhu–Barber as above. A re-analysis would need a specific claim not already explained by their selection/coverage results.

## Current priority/correction limitations

Zeng's arXiv page still exposed v2 in this check. The official proceedings page and its OpenReview link were inspected; the discussion returned a browser-verification challenge. No conclusion is drawn about the absence of corrections or discussions. We did not inspect every citing paper or establish independent priority. A full novelty sign-off is therefore pending, despite completed local mathematical work.
