# Evidence and decision: temperature-scaled LAC calibration reuse

**30 September 2026. Mathematical candidate with reproducible checks; originality and practical significance not independently established. Not a conference paper.**

## Decision

One candidate survived the technical checks: a softmax-specific characterization of what can happen when a global temperature is selected on the calibration sample and ordinary LAC calibration then reuses that sample.

The possible advance is the combination of (i) a sharp leading-order class-count complexity characterization, (ii) a local realization theorem embedding arbitrary finite score families inside one fixed standard softmax model, and (iii) an exact coverage-loss construction in that model. The standard VC inequality, finite-family selection bias, inverse-function theorem, and Gaussian/order-statistic arguments are not new contributions.

This improves substantially on the attached abstract scalar counterexample: it concerns an actual, widely used functional family, gives a positive guarantee, and demonstrates genuine coverage loss in that same family. It does **not** establish that normal likelihood-based temperature tuning fails, or provide a superior practical reuse procedure.

Full mathematical arguments and all assumptions are in `PROOFS.md`. Candidate comparisons, three closest sources per direction, current revisions, and priority caveats are in `PRIOR_WORK.md`.

## Candidate gate

A. Generic stability-based reuse: rejected as a novelty claim because stable conformal prediction, leave-one-out stable prediction, and stable selection already cover this methodology. No genuinely new observable certificate was obtained.

B. Generic exact reuse or safe candidate screening: rejected as a novelty claim because ModSel-CP/LOO and localized conformal model selection already supply strong relevant alternatives. No new computational advantage was proved or measured.

C. Structural characterization of ordinary temperature-scaled LAC: developed. Mathematical claims survived attempted counterexamples and the executed checks; priority and significance remain open.

D. Released-logit conclusion reversal: not launched. TS4CP file metadata and the documented array schema were verified, but binary arrays were not loaded. No distinct empirical hypothesis strong enough to exceed already-known selection effects was established. There is no real-data result in this package.

These are decisions about the specific proposals investigated, not claims that whole research areas are exhausted.

## Precise results

For the threshold family of K-class positive-temperature softmax target probabilities, let d_K be its VC dimension and Pi_K(m) its number of possible threshold labelings on m points.

1. `Pi_K(m) <= min(2^m, m+1+(K-2)m(m-1))`.
2. `d_K >= floor(log2(K-1))`, and `d_K/log2(K) -> 1`.
3. A fixed smooth K-class logit map can locally realize K-1 arbitrary bounded score coordinates at K-1 positive temperatures, up to known monotone transformations. This remains an existence result even with a fixed nondegenerate logit/temperature interval; its margins may be tiny.
4. Under iid calibration/test data and a classifier fixed independently of calibration, arbitrary measurable temperature selection followed by same-data ordinary LAC has expected conditional undercoverage bounded by a universal constant times `sqrt(log(K)/n)`, capped at one. The empirical-process step is standard, not a new theorem. The explicit conservative bound in `PROOFS.md` has an additional log(n); the sharper unspecified-constant statement uses classical VC entropy control.
5. An actual softmax construction has conditional coverage equal to the minimum of M=K-1 independent `Beta(k,n+1-k)` variables, where `k=ceil((n+1)(1-alpha))`. Thus its finite-n marginal coverage is exactly an integral of the Mth power of a Beta survival function.
6. For fixed M and n tending to infinity, the square-root-n-scaled coverage loss tends to `sqrt(c(1-c)) E max_{r<=M} G_r`, with independent standard-normal G_r. As M subsequently tends to infinity, this is asymptotic to `sqrt(2c(1-c) log(M))`. **This iterated-limit result is not a uniform nonasymptotic matching lower bound for every joint n,K regime.**
7. The small-class boundaries are d_2=1 and d_3=2. Binary invariance is explicitly acknowledged as already known from Zeng et al. Exact d_4 was not determined.

The last construction rules out a class-count-independent universal constant times `1/sqrt(n)` guarantee for arbitrary selectors using unmodified same-data LAC. It does not rule out exact-valid selection methods that change the calibration construction.

## Actual softmax experiment

The complete explicit three-class model is in `PROOFS.md`, Section 8. It uses two independent uniform feature coordinates, two inverse temperatures {1,2}, and the target label has the largest logit for every point. Model logits are a fixed function, not trained on calibration data.

The prespecified selector minimizes the normalized conformal cutoff over the two temperatures. It is deliberately adversarial. A 90% nominal target and n=99 give k=90. For each of 10,000 independent calibration experiments, the code constructs logits, computes actual softmax probabilities, selects the temperature, calculates the ordinary LAC order-statistic cutoff, and analytically integrates fresh-test coverage conditional on that calibration sample.

| Procedure | Total observations | Expected coverage | Measured coverage | 95% Monte Carlo interval |
|---|---:|---:|---:|---:|
| Reuse, minimum-normalized-quantile selector | 99 | 88.328680% | 88.284802% | 88.231271–88.338333% |
| Fixed inverse temperature 1 | 99 | 90.000000% | 89.947954% | 89.889599–90.006309% |
| Tune on 99, calibrate independently on 99 | 198 | 90.000000% | 90.047410% | 89.988867–90.105954% |
| Same total data: tune on 50, calibrate on 49 | 99 | 90.000000% | 89.941115% | 89.858025–90.024205% |
| NLL tuning over the same two-temperature grid | 99 | 90.000000% | 89.996540% | 89.937702–90.055379% |

`results/coverage_main.csv` contains unrounded values and Monte Carlo standard errors. `results/coverage_raw.npz` contains the replication-level observations. Intervals describe simulation uncertainty, not frequency of the problem in real applications.

The maximum discrepancy between cutoffs recovered from actual softmax scores and the latent order statistics was approximately 7.61e-14, below the locked 1e-10 tolerance.

The paired independent-minus-reuse mean was 1.762608 percentage points, with 95% Monte Carlo interval 1.683462–1.841755. Its exact expectation is 1.671320 points; this is outside that nominal 95% interval, 2.261 standard errors from the observed mean. This discrepancy is retained. It meets the predeclared five-standard-error diagnostic tolerance. Seeds were not changed to improve agreement.

### Necessary negative control

Ordinary NLL selection over {1,2} always picks inverse temperature 2 in this constructed model: every competing logit is below the target logit, so sharpening reduces each observation's true-label NLL. The observed 89.9965% result agrees with exact 90% coverage. **There is no experimental evidence here that NLL tuning causes undercoverage.**

The model is perfectly classified and its LAC sets can be empty. Forcing the argmax into every set changes the procedure and eliminates the failure on this specific construction. This limitation is not hidden by using a larger simulation.

### Larger-family diagnostics

Fifteen additional cells use n in {99,499,1999} and M in {1,2,4,16,64}, with 20,000 repetitions per cell. These sample the analytically derived Beta law directly. They are **not** numerical realizations of the full inverse-softmax construction for every M. All matched their exact expectations within the locked five-standard-error tolerance. Raw values are preserved in the same NPZ; summaries are in `results/coverage_law_diagnostics.csv`.

## Failed witnesses and exact verification

An exploratory integer-logit search produced an apparent eight-pattern K=4 witness. Exact rational evaluation rejected it: floating-point dominant-term rounding had created a false ordering/tie. Its certified pattern count is seven. The failed candidate, original float output, and exact reason remain in `results/exploratory_search.json` and `results/exact_integer_audit.json`.

The K=5,6,9 eight-pattern integer witnesses survived exact checking. Independent interpolation certificates verify 2,4,8,16 patterns on 1,2,3,4 points using 3,5,9,17 classes. Their rational identities and Taylor-remainder bounds are exact; high-precision exponentials provide an additional check, not the proof. Tiny margins at the larger certificates highlight finite-precision limitations rather than establish common practical failure.

Fifteen tests passed. They include independent rational witness recomputation, preservation of the failed witness, exact small Jacobian determinants, embedding bounds, actual softmax identities, NLL behavior, order-statistic indexing, binary invariance, protocol hashes, and statistical reconstruction from raw outputs. Neither tests nor the author of this analysis constitute independent mathematical peer review.

## Resources and reproducibility

Five externally timed research commands used **13.51 CPU seconds** in total, with **152.89 MiB** maximum resident memory. The actual softmax experiment plus its Beta-law diagnostics used **3.02 CPU seconds**. Hardware: hosted AMD EPYC 9V74, Linux x86-64, Python 3.13.5; dependencies recorded in `results/environment.json`.

This is not a laptop timing claim. Literature search, reasoning, writing, dependency setup, and artifact packaging are outside the five experimental timing measurements. No GPU, model training, model API, or separately provisioned paid cloud computation was used. The numerical workload is comfortably inside the requested resource budget.

The first local protocol predates the exploratory witness search. The coverage extension was derived and added later, then separately locked before the coverage experiment. Both are retained; neither was independently preregistered. File hashes establish delivered-byte integrity, not an external timestamp or priority.

## Adversarial review

**Originality:** unresolved. The specific realization/complexity/coverage combination was not located in the primary sources inspected, but a search miss does not establish novelty. The components use classical ideas. Existing specialized VC or calibration results could subsume the claim.

**Correctness:** complete arguments are supplied for the scope stated above, with symbolic and numerical checks. Independent review is still needed, particularly of the arrangement count, the local realization claim under restricted intervals, and the scope of asymptotic matching. No unproved uniform joint-regime lower bound is claimed.

**Significance:** strongest for researchers trying to prove temperature-reuse guarantees. The result supplies a sharper structural target and a compact actual-softmax stress test. It does not yet change a deployment recommendation or beat existing valid-selection methods.

**Fairness:** the independent control uses additional data, and this is clearly counted; a same-total-data split control is included. No comparison against ModSel-CP/LOO or localized selection was executed, so no speed/efficiency superiority is claimed.

**Practical objections:** adversarial selector; perfectly classified constructed distribution; empty prediction sets; tiny possible margins as class count grows; untested finite precision; LAC rather than APS/RAPS. These prevent an unrestricted practical claim.

**Priority/corrections:** current arXiv revisions and the official target proceedings were checked. The linked OpenReview discussion could not be read because it returned a browser challenge. Absence of corrections is not established.

## Paper decision and next meaningful question

Do not turn this package into a top-tier submission solely because it contains theorems and a nonzero gap. It is a substantive mathematical candidate, but novelty sign-off, independent proof checking, and a stronger case for practical significance remain missing.

The next specific question is: **Does the ordinary NLL temperature estimator admit a sharper, useful reuse guarantee under verifiable curvature and score-margin conditions, avoiding a vacuous worst-case class-family bound?** That question must face the existing stability and model-selection literature; applying their theorems without a new certificate or sharpness result is not a contribution.
