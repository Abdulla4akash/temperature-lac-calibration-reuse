"""Verify the unmodified delivered archive. Regenerated runtime fields change hashes."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
fail=[]
for name,wanted in manifest['sha256'].items():
    p=root/name
    if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=wanted:fail.append(name)
if fail:
    print('Changed or missing files:',*fail,sep='\n');sys.exit(1)
print(f"Verified {len(manifest['sha256'])} file hashes.")
