# Temperature-scaled LAC: structural complexity and a coverage-loss construction

**Research evidence note — 30 September 2026. Not a submission manuscript.**

The arguments below were developed during this investigation. Their priority is not established. The standard empirical-process theorem, inverse-function theorem, finite-family selection phenomenon, and order-statistic asymptotics are not claimed as new. No independent mathematician or proof assistant has checked this note.

## 1. Scope and notation

Let K >= 2. A fixed classifier supplies finite real logits z=(z_1,...,z_K). For inverse temperature beta>0, let

\[
p_\beta(y\mid z)=\frac{e^{\beta z_y}}{\sum_{j=1}^K e^{\beta z_j}},\qquad
S_\beta(z,y)=1-p_\beta(y\mid z).
\]

This is ordinary, nonrandomized least-ambiguous classification (LAC). The logits are fixed independently of the calibration observations. Only the single GLOBAL temperature may be selected on those observations. No feature-dependent temperature, neural-network refitting, vector scaling, APS, RAPS, or forced-inclusion-of-argmax modification is included in the coverage statements.

Define the threshold class

\[
\mathcal H_K=\{(z,y)\mapsto 1\{p_\beta(y\mid z)\ge t\}:\beta>0,\;t\in[0,1]\},
\]

its growth function Pi_K(m), and its VC dimension d_K. The domain is all finite logit-label pairs; restricting to the output of any particular fixed model can only decrease complexity. VC dimension is the largest m for which all 2^m include/exclude patterns on some m points can be represented. It is NOT a measurement of a particular fitted temperature's error.

## 2. Theorem 1: an explicit growth bound

For every integer m>=1,

\[
\boxed{\Pi_K(m)\le \min\{2^m,\ m+1+(K-2)m(m-1)\}.}
\]

Consequently

\[
d_K\le \max\{m\ge1:2^m\le m+1+(K-2)m(m-1)\}.
\]

This inequality is an upper bound, not an exact formula for every small K.

### 2.1 Elementary zero-count lemma

A nonzero function \(f(b)=\sum_{j=1}^r c_j e^{a_j b}\), with distinct real a_j and nonzero coefficients, has at most r-1 distinct real zeros.

Proof by induction on r. The claim is immediate for r=1. Multiply by e^{-a_1 b}; this does not change zeros. Its derivative has r-1 exponential terms with distinct exponents and nonzero coefficients, hence at most r-2 zeros by induction. If the original function had r or more distinct zeros, Rolle's theorem between consecutive zeros would force at least r-1 derivative zeros. Contradiction. The same argument excludes infinitely many zeros by choosing a sufficiently large finite subset. This is a classical exponential-Chebyshev argument, not our novelty.

### 2.2 Score crossings

For a sampled point i, subtract its target logit from every logit. Its inverse target probability is

\[
A_i(b)=1+\sum_{j\ne y_i}e^{b(z_{ij}-z_{iy_i})}.
\]

For two points i,l, the difference A_i-A_l, after cancelling and combining equal exponents, has at most 2(K-1) terms. If it is not identically zero, the preceding lemma gives at most 2K-3 real zeros. One of them is b=0, since A_i(0)=A_l(0)=K. Thus there are at most 2K-4 intersections at b>0. Identical curves can be merged; they cannot be assigned different threshold labels.

### 2.3 Counting threshold patterns without an extra factor of m

Consider the graphs u=A_i(b) in the open half-plane b>0. Adding one graph to the arrangement of earlier graphs creates at most one plus its number of distinct intersections with earlier graphs new regions. Its pieces between intersections each lie in one existing region and split that region into at most two. Summing over the m graphs gives at most

\[
1+m+\sum_{i<l}\#\{b>0:A_i(b)=A_l(b)\}
\le m+1+(2K-4)\binom m2
\]

regions. Tangencies and simultaneous intersections do not increase this upper bound; pairwise counting only overcounts them.

Each strict threshold labeling is constant in an open region. A labeling at an equality point under the convention A_i<=u is also realized in an open region: first raise u a sufficiently small amount so all equalities become strict inclusions without including any previously excluded point; then perturb b, using continuity. Therefore equality conventions do not introduce extra patterns. Restricting u to the range corresponding to probabilities t in[0,1] cannot increase their number. This proves Theorem 1.

## 3. Theorem 2: local finite-family realization inside ordinary softmax

Let M=K-1. There exist positive inverse temperatures beta_1,...,beta_M, constants a_r>1, delta>0, and a FIXED continuous map

\[
z:[0,1]^M\longrightarrow\mathbb R^K
\]

such that, with y=1,

\[
\boxed{\frac1{p_{\beta_r}(1\mid z(u))}=a_r+\delta u_r\quad(r=1,...,M).}
\]

The target logit can be zero and all competing logits strictly negative. Consequently, arbitrary M bounded score functions u_r(x) can be realized, up to known strictly increasing score transformations, at M temperatures of ONE fixed softmax model.

### Proof through power sums

Choose distinct numbers 0<w_1^0<...<w_M^0<1, and beta_r=r. Define

\[
F_r(w)=\sum_{j=1}^M w_j^r,\quad r=1,...,M.
\]

The Jacobian has entries J_{rj}=r w_j^{r-1}; its determinant is

\[
\det J=\left(\prod_{r=1}^M r\right)\prod_{i<j}(w_j-w_i)\ne0.
\]

By the inverse-function theorem, F is a diffeomorphism between sufficiently small open neighborhoods of w^0 and F(w^0). The neighborhood in w can be chosen entirely inside the strictly ordered cube (0,1)^M. The image is open, so it contains F(w^0)+delta[0,1]^M for some delta>0. For each u define w(u) by this local inverse and take

\[
z(u)=(0,\log w_1(u),...,\log w_M(u)).
\]

At beta_r=r, the softmax denominator is 1+F_r(w(u))=1+F_r(w^0)+delta u_r. Set a_r=1+F_r(w^0). The construction uses no calibration observations, so it does not hide calibration leakage in the classifier. This proves the claim.

### Restrictions to bounded logits and a fixed temperature interval

The same local existence result holds with beta_r chosen as distinct points in any nonempty open positive interval and competing logits chosen in any nonempty interval (-B,0). In the logit coordinates c_j, the Jacobian is beta_r exp(beta_r c_j). If its exponential matrix were singular, a nonzero M-term exponential polynomial would vanish at all M distinct beta_r, contradicting the zero-count lemma. Apply the same inverse-function argument within the specified logit box. The allowable delta may be extremely small. This assertion is about exact real arithmetic, NOT a finite-precision or margin guarantee.

### Class-label balance

A fixed true label suffices for the worst-case theorem. To have every label occur, independently draw a uniform class index J, include it as a perfectly informative feature, set Y=J, and permute the constructed logit vector so the target coordinate occupies position J. The coverage law is unchanged. This remains a deliberately constructed, perfectly classified problem, not a representative real dataset.

## 4. Theorem 3: asymptotically sharp VC complexity

\[
\boxed{d_K\ge\lfloor\log_2(K-1)\rfloor,\qquad
\lim_{K\to\infty}\frac{d_K}{\log_2 K}=1.}
\]

Proof of the lower bound. Set m=floor(log_2(K-1)). At least 2^m temperature coordinates are available in Theorem 2. Enumerate all binary patterns b^(r) on m points. For point i, prescribe u_r=0 when b_i^(r)=1 and u_r=1 otherwise; set unused coordinates arbitrarily. Use the fixed inverse map to obtain this point's logits. At temperature r, threshold the inverse probability at a_r+delta/2. The desired pattern is obtained. The m points are therefore shattered.

For the asymptotic upper bound, Theorem 1 implies 2^d <= d+1+(K-2)d(d-1). First this gives d=O(log K), because an exponential in d eventually dominates K times a quadratic in d. Substituting that crude bound back gives

\[
d\le\log_2 K+2\log_2\log_2 K+O(1).
\]

The lower bound is log_2 K-O(1), proving the ratio limit. The explicit finite-m inequality, rather than an unstated asymptotic constant, is the numerically usable upper bound.

### Independent constructive certificate

`source/interpolation_certificate.py` implements a second proof route for m=1,2,3,4. Let q=2^m, select rational t_r in(1,2), baseline exponents c_j=-j-1, and solve the rational system

\[
\sum_j v_{ij}t_r^{c_j}=s_{ir}\in\{-1,+1\}.
\]

Let H>=1 bound all |v_ij|, put w_ij=v_ij/H, and epsilon=1/(6qH). Perturb c_j by epsilon*w_ij. For beta_r=log t_r, the first-order denominator change is epsilon*beta_r*s_ir/H. Because |w_ij|<=1, 0<beta_r<1, c_j<0, and e^{epsilon beta |w|}<3, the Taylor remainder has magnitude at most

\[
\frac32q\epsilon^2\beta_r^2\le\frac14\frac{\epsilon\beta_r}{H}.
\]

Thus every sign is certified. The rational interpolation identities and the 1/4 bound are exact; the 160-decimal exponential calculations are a separate numerical cross-check.

## 5. Small-class boundary cases

### K=2: known invariance, not a new result

The reciprocal target probability is 1+exp(beta a), where a is the competing-minus-target logit margin. Every beta>0 preserves the ordering of a across examples and candidate labels. Any empirical quantile therefore yields exactly the same LAC prediction sets, including ties, whatever data-dependent positive temperature is chosen. d_2=1. Zeng et al. already state the binary order-preservation and zero-tuning-bias result (Proposition 5.1; Lemma D.8).

### K=3: d_3=2

There are two competing gaps a,b. Write u=(a+b)/2 and v=|a-b|/2. Their sum of exponentials is 2exp(beta u)cosh(beta v). Equality between two curves is equivalent to

\[
u_1-u_2+\frac{\log\cosh(\beta v_1)-\log\cosh(\beta v_2)}\beta=0.
\]

When v_1>v_2, the second term is strictly increasing in beta: its derivative has numerator g(beta v_1)-g(beta v_2), where g(x)=x tanh x-log cosh x and g'(x)=x sech^2 x>0 for x>0. If v_1=v_2 the difference is constant or the curves coincide. Each distinct pair therefore crosses at most once. The arrangement argument bounds patterns on m points by m+1+binom(m,2). At m=3 this is 7<8, so d_3<=2.

For a lower bound, choose competing gaps (-1,-10) for one point and (-4,-4) for another. Near beta=0, the first exponential sum is smaller because its first derivative is -11 rather than -8; for large beta, its exp(-beta) term makes it larger. Both strict orderings occur. Together with empty/full patterns this shatters two points. Hence d_3=2.

No exact value of d_4 is claimed. An exploratory floating-point three-point witness at K=4 FAILED exact arithmetic. That failure is retained rather than replaced by an assertion of shattering. A K=5 integer-logit witness did pass exact rational verification.

## 6. Theorem 4: a valid reuse upper bound

Assume calibration pairs D=(Z_i,Y_i), i=1,...,n, and a fresh test pair are iid, conditional on any independent model-training data. Let beta_hat be any measurable positive function of D. For c=1-alpha, let k=ceil((n+1)c), and use the kth order statistic of S_{beta_hat}(Z_i,Y_i) as the usual LAC cutoff. If k=n+1, output the full label set.

Writing Cov(D)=P(Y_test in C_D(Z_test)|D), there are universal constants C,C' such that

\[
\boxed{\mathbb E[(c-\mathrm{Cov}(D))_+]\le
\min\{1,C\sqrt{d_K/n}\}\le\min\{1,C'\sqrt{\log K/n}\}.}
\]

The final rate is uniform over the classifier, the data distribution, and the temperature-selection rule. It is NOT exact finite-sample coverage at c, nor is its unspecified constant an operational sample-size recommendation.

Proof. When k<=n, the selected threshold indicator h_D belongs to H_K and P_n h_D>=k/n>=c. Therefore

\[
(c-P h_D)_+\le \sup_{h\in\mathcal H_K}|P_n h-P h|.
\]

Apply the standard Boolean VC empirical-process bound E sup|P_n-P|<=C sqrt(d_K/n), then Theorems 1 and 3. This empirical-process reduction is established prior work, including the valid Lemma D.6 of Zeng et al.; it is not claimed as a new learning theorem. Measurability can be handled by the usual separable version (or outer expectations); the finite-dimensional continuous score parametrization admits approximation of weak thresholds by countably many strict perturbed thresholds.

For an explicit, though more conservative, finite-n bound, symmetrization and the finite-class Rademacher bound give

\[
\mathbb E\sup_h|P_nh-Ph|\le
2\sqrt{\frac{2\log(2B_{K,n})}{n}},\qquad
B_{K,n}=\min\{2^n,n+1+(K-2)n(n-1)\}.
\]

The logarithm can be evaluated without materializing 2^n. Bounded differences adds sqrt(log(1/delta)/(2n)) for a high-probability bound. This explicit expression has an extra log n relative to the sharper entropy-integral result. We do NOT silently remove that factor from the explicit constant formula. Standard cutoff inflation can use this bound, but it may be conservative/vacuous and is not a new proposed practical algorithm.

## 7. Theorem 5: a real coverage lower construction within the same score family

Set M=K-1. Take independent U_r~Uniform[0,1] and the fixed logit map in Theorem 2. Use iid observations of these features. For each temperature r, let B_r be the kth order statistic of its n calibration U-coordinates. Then B_1,...,B_M are INDEPENDENT Beta(k,n+1-k) variables.

Select r_hat=argmin_r B_r and perform ordinary LAC calibration at temperature r_hat on the same n observations. This is a measurable, calibration-only selector: B_r is recoverable from its LAC cutoff q_r as

\[
B_r=\frac{1/(1-q_r)-a_r}{\delta}.
\]

It does not access a test label. It is deliberately adversarial and is NOT an NLL/temperature-likelihood optimizer or a claim about every sensible selection algorithm.

For a fresh test observation, true-label inclusion is exactly U_{r_hat}<=B_{r_hat}. Conditional coverage is therefore min_r B_r. Consequently

\[
\boxed{\mathrm{Coverage}_{n,M}=\int_0^1
[1-F_{\mathrm{Beta}(k,n+1-k)}(t)]^M\,dt.}
\]

Every fixed temperature has marginal coverage c_n=k/(n+1). Thus its exact expected loss from this reuse selector is

\[
\boxed{\Delta_{n,M}=c_n-\mathbb E\min_{r\le M}B_r.}
\]

This is a finite-n constructive lower example for unmodified same-data calibration, not an impossibility result for full conformal, ModSel-CP, split calibration, or all reuse procedures.

### Precisely stated rate comparison

Take any fixed c in(0,1), k_n=ceil((n+1)c), and fixed M. Uniform order-statistic asymptotics give joint convergence of sqrt(n)(B_r-c_n) to independent normals with variance c(1-c). This follows directly from the binomial representation of the order-statistic CDF and the binomial CLT. Expectations converge as well: n Var(B_r)=n c_n(1-c_n)/(n+2) is bounded, and for fixed M the squared maximum deviation is bounded by the sum of M squared deviations. Hence this family is uniformly integrable.

Let a_M=E max_{r<=M} G_r for independent standard normals. Symmetry then gives

\[
\lim_{n\to\infty}\sqrt n\,\Delta_{n,M}=\sqrt{c(1-c)}\,a_M.
\]

For completeness, a_M/sqrt(2 log M)->1: the upper bound follows from the exponential moment/union bound for Gaussian maxima; for every epsilon>0, the Gaussian tail lower bound implies M P(G>(1-epsilon)sqrt(2 log M))->infinity, so the maximum exceeds that level with probability approaching one. Its negative part has vanishing/bounded contribution after division by sqrt(log M). Thus

\[
\boxed{\lim_{M\to\infty}\lim_{n\to\infty}
\frac{\sqrt n\,\Delta_{n,M}}{\sqrt{2c(1-c)\log M}}=1.}
\]

This is the EXACT iterated-limit statement proved here. No uniform nonasymptotic Omega(sqrt(log K/n)) bound over every joint n,K regime is claimed. Nevertheless it rules out a universal K-independent C/sqrt(n) bound for arbitrary temperature selectors: choose fixed M so sqrt(c(1-c))*a_M>C, then let n increase. The upper and lower results therefore match the logarithmic class-count dependence in this stated sense.

## 8. Explicit K=3 construction used in the actual experiment

Use delta=1/100, U_1,U_2 independent uniforms, and define

\[
s=1+\delta U_1,\quad v=5/8+\delta U_2,\quad
w_-=(s-\sqrt{2v-s^2})/2,\quad w_+=(s+\sqrt{2v-s^2})/2.
\]

Here 2299/10000 <= 2v-s^2 <= 27/100. Its square root is below .52; s is in[1,1.01], so 0<w_-<w_+<1. Set z=(0,log w_-,log w_+), with true label 1.

Because w_-+w_+=s and w_-^2+w_+^2=v,

\[
p_1(1|z)^{-1}=2+.01U_1,\qquad
p_2(1|z)^{-1}=13/8+.01U_2.
\]

This is an explicit global realization on the entire unit square, not merely a numerical inverse-function approximation. No ties arise in calibration with probability one. At n=99 and c=.9, k=90, so fixed coverage is exactly .9 and the selected coverage is the mean of the minimum of two independent Beta(90,10) variables. Numerical quadrature gives 0.8832868013664341.

NLL over the SAME grid {1,2} always selects 2: all competing w are in(0,1), so w^2<w and the true-label negative log probability is lower at 2 for every observation. Thus this example is explicitly a NEGATIVE control against claiming ordinary NLL tuning fails. The numerical study confirms this.

The resulting LAC sets may be empty. Forcing the argmax label into every set changes the procedure and, on this perfectly classified construction, removes the failure. We do not claim a lower bound for that modified method.

## 9. Boundaries and unresolved matters

Completed mathematical arguments: finite crossing bound, growth bound, local realization, sharp leading-order VC complexity, the iid reuse upper bound, exact coverage-loss law, its stated iterated-limit comparison, binary invariance, and the ternary VC boundary. Numerical checks do not substitute for these proofs.

Not completed or claimed: independent mathematical review; priority determination; an NLL-specific worst-case characterization; a useful sharp finite-precision/margin bound; a practical improvement over ModSel-CP or other valid selection procedures; real-data replication; exact d_4; a uniform joint-regime matching lower bound. The numerical K=4 floating-point false witness is retained.

## References most directly used

1. Zeng, Liu, Jing, Wei. Parametric Scaling Law of Tuning Bias in Conformal Prediction. ICML 2025. https://proceedings.mlr.press/v267/zeng25e.html . Inspected arXiv version: https://arxiv.org/html/2502.03023v2 . Binary result and VC empirical-process reduction are prior work.
2. Yang and Kuchibhotla. Selection and Aggregation of Conformal Prediction Sets. https://arxiv.org/html/2104.13871v3 . Finite-family selection and correction precede this work.
3. Liang, Zhu, Barber. Conformal prediction after data-dependent model selection. https://arxiv.org/html/2408.07066v4 . Exact validity after selection is already achievable using a different construction.
4. Mattei and Loureiro. The Well-Tempered Classifier: Some Elementary Properties of Temperature Scaling. https://arxiv.org/html/2602.14862v2 . Ordinary likelihood, entropy, and accuracy-preservation properties are prior work.
5. Dabah and Tirer. On Temperature Scaling and Conformal Prediction of Deep Classifiers. https://arxiv.org/html/2402.05806v3 . Temperature/conformal efficiency trade-offs are prior work.

The foundational zero-count, inverse-function, Vandermonde, empirical-process, and order-statistic tools are explicitly NOT claimed as original. The possible contribution is the precise softmax-specific realization/complexity/coverage characterization assembled and proved above. Priority remains open to challenge.
