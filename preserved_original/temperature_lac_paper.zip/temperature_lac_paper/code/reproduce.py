#!/usr/bin/env python3
"""Rerun preserved research and new checks into a NEW output directory."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import numpy as np

ROOT=Path(__file__).resolve().parents[1]

def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True,help='New directory; must not exist')
    args=parser.parse_args()
    output=args.output.resolve()
    if output.exists():
        raise SystemExit(f'Refusing to overwrite existing directory: {output}')
    source=ROOT/'original/calibration_reuse_followup'
    output.mkdir(parents=True)
    work=output/'original_rerun'
    shutil.copytree(source,work)
    env=os.environ.copy()
    env.update(OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
    logs=[]
    commands=[
        (work, [sys.executable,'verify_manifest.py']),
        (work, [sys.executable,'source/search_witness.py']),
        (work, [sys.executable,'source/verify_integer_witnesses.py']),
        (work, [sys.executable,'source/interpolation_certificate.py']),
        (work, [sys.executable,'source/coverage_embedding.py']),
        (work, [sys.executable,'tests/test_research.py']),
        (ROOT, [sys.executable,str(ROOT/'code/audit_checks.py')]),
        (ROOT, [sys.executable,str(ROOT/'code/chain_certificate.py')]),
    ]
    env['LAC_AUDIT_OUTPUT']=str(output/'new_checks')
    for index,(cwd,command) in enumerate(commands,1):
        start=time.perf_counter()
        log=output/f'command_{index:02d}.txt'
        with log.open('w') as handle:
            result=subprocess.run(command,cwd=cwd,env=env,stdout=handle,stderr=subprocess.STDOUT,check=False)
        logs.append(dict(command=command,cwd=str(cwd),returncode=result.returncode,
                         wall_seconds=time.perf_counter()-start,log=log.name))
        if result.returncode:
            (output/'execution.json').write_text(json.dumps(logs,indent=2))
            raise SystemExit(f'Command failed ({result.returncode}); see {log}')
    compare={}
    for name in ('coverage_main.csv','coverage_law_diagnostics.csv'):
        compare[name]=(source/'results'/name).read_bytes()==(work/'results'/name).read_bytes()
    with np.load(source/'results/coverage_raw.npz',allow_pickle=False) as a, np.load(work/'results/coverage_raw.npz',allow_pickle=False) as b:
        compare['raw_arrays']={key:bool(np.array_equal(a[key],b[key])) for key in a.files}
    a=json.loads((source/'results/exploratory_search.json').read_text())
    b=json.loads((work/'results/exploratory_search.json').read_text())
    compare['search']={key:a[key]==b[key] for key in ('results','t_numerators','t_denominator','seed')}
    (output/'execution.json').write_text(json.dumps(logs,indent=2)+'\n')
    (output/'comparison.json').write_text(json.dumps(compare,indent=2)+'\n')
    ok=all(compare[k] for k in ('coverage_main.csv','coverage_law_diagnostics.csv'))
    ok=ok and all(compare['raw_arrays'].values()) and all(compare['search'].values())
    print(json.dumps({'status':'PASS' if ok else 'OUTPUT_DIFFERENCE','output':str(output)},indent=2))
    if not ok:
        raise SystemExit('Output difference: inspect versions and logs; do not overwrite reference results.')

if __name__=='__main__':main()
