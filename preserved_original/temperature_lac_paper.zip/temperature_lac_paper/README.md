# Temperature-scaled LAC: manuscript, audit, and reproduction package

## Start here

- **`manuscript/main.pdf`** — 15-page standalone theory manuscript with complete proofs and a numerical illustration.
- **`audit/CORRECTNESS_AUDIT.md`** — claim-by-claim audit, assumptions, repairs, and rejected interpretations.
- **`audit/NOVELTY_AUDIT.md`** — theorem-level primary-literature comparison, versions, access limitations, and priority risks.
- **`audit/EXECUTION_REPORT.md`** — actual reproduction results, resources, and deviations.
- **`CLAIM_EVIDENCE.csv`** — each main claim mapped to its theorem, proof and computational evidence.

**Decision:** ready for independent expert review of the mathematics and originality case; not represented as externally verified, submitted, or established as novel. No proof step is intentionally left unresolved in the manuscript's central theorems. The outstanding issue is specialist priority/significance review of the specific softmax characterization and coverage transfer—not a missing large experiment.

## What changed from the attached preliminary package

The original growth, realization, leading VC and coverage arguments survived independent rederivation. The Beta law now explicitly excludes k=n+1, which gives full sets and coverage one. Coverage quantities and the nominal rounding correction are separated. A new uniform finite-sample lower argument replaces reliance on the original iterated limit. A symmetric-chain refinement sharpens the finite VC lower bound and supplies distinct exact Taylor-certified witnesses at K=4 and K=7. The original failed floating-point K=4 witness remains rejected and preserved.

No new model, training run, GPU job, paid model API or real-data experiment was used. The lower selector is adversarial; NLL does not fail in the explicit example. Full-conformal and other validity-preserving reuse procedures are outside the lower bound.

## Preservation

`original/calibration_reuse_followup.zip` is a byte-for-byte copy of the attached archive. Its SHA256 is:

`31114a670b27a34f8e43b2f95802de822caf79f202726513681a07d1800b263b`

`original/calibration_reuse_followup/` is the unmodified extraction. Its original 32-file manifest passes. All reruns were carried out elsewhere. `reproduction/package/` contains the first separately rerun copy and `reproduction/` contains its external timing and comparison records. Machine-dependent timing metadata need not match the original.

## Reproduce all numerical checks

The tested environment is Python 3.13.5, NumPy 2.3.5, SciPy 1.17.0, SymPy 1.14.0 and mpmath 1.3.0 on Linux. Dependencies are pinned in `requirements.txt`. The code requires a Unix-like system for the preserved search script's CPU resource limit. No network access is needed once dependencies are present.

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python code/reproduce.py --output /tmp/lac-reproduction-new
```

The destination must not exist. The runner refuses to overwrite it, copies the preserved tree, verifies its manifest, reruns the search and exact audits, reruns the main coverage study and tests, runs new independent checks and Taylor certificates, and compares the outputs. This runner itself was tested end to end and passed. Exact bitwise equality assumes the pinned tested environment; a mismatch on another platform must be examined, not silently discarded.

The core coverage rerun consumed **2.60 CPU seconds**. All eight instrumented research commands, including duplicated checks and the end-to-end clean runner, consumed **30.79 CPU seconds** in total, with peak recorded resident memory **152.03 MiB**. These are hosted AMD EPYC CPU measurements, not laptop timings. They exclude literature work, mathematical reasoning, writing, rendering, packaging and uninstrumented setup.

## Individual new checks

```bash
LAC_AUDIT_OUTPUT=/tmp/lac-checks-new python code/audit_checks.py
LAC_AUDIT_OUTPUT=/tmp/lac-checks-new python code/chain_certificate.py
```

Use a fresh output path to preserve delivered results. The first script performs 12 named tests, exact rational integration and a 48-cell deterministic integration grid. The second checks ten finite symmetric-chain decompositions and two new rational/Taylor certificates; its 160-digit exponential calculations are secondary checks, not the certificate itself.

## Build the paper

```bash
cd manuscript
./build.sh
```

This uses `pdflatex` and, when available, `bibtex`. Both `references.bib` and the matching `main.bbl` are supplied. BibTeX was unavailable in the execution environment, so the bibliography was rendered explicitly into `main.bbl` from the verified entries and the document was compiled with repeated `pdflatex` passes. No unresolved citations or cross-references remain. See `audit/BUILD_AND_LAYOUT_REPORT.md` for visual checks.

The manuscript is anonymous because authorship and submission declarations have not been assigned. It explicitly records AI assistance. Human authorship, venue-specific requirements and expert approval remain outside this execution.

## Verify delivered file integrity

```bash
python verify_package.py
```

`PACKAGE_MANIFEST.json` stores relative-path SHA256 values for all delivered files except the manifest itself. Integrity validation does not establish mathematical correctness.
