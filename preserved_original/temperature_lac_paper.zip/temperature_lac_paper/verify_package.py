#!/usr/bin/env python3
"""Check release hashes and byte-for-byte preservation of the input archive.

Uses only the Python standard library. This does not rerun experiments or
validate a mathematical theorem. Additional local files are reported, not
removed. Run on the delivered package before rebuilding the manuscript.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
ORIGINAL_SHA256 = "31114a670b27a34f8e43b2f95802de822caf79f202726513681a07d1800b263b"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def verify_map(root: Path, expected: dict[str, str]) -> list[str]:
    failures: list[str] = []
    resolved_root = root.resolve()
    for name, wanted in expected.items():
        path = (root / name).resolve()
        if not path.is_relative_to(resolved_root):
            failures.append(f"Unsafe relative path: {name}")
        elif not path.is_file():
            failures.append(f"Missing file: {name}")
        elif digest(path) != wanted:
            failures.append(f"Hash mismatch: {name}")
    return failures


def main() -> int:
    try:
        release = json.loads((ROOT / "PACKAGE_MANIFEST.json").read_text())
        failures = verify_map(ROOT, release["sha256"])
        archive = ROOT / "original/calibration_reuse_followup.zip"
        if not archive.is_file() or digest(archive) != ORIGINAL_SHA256:
            failures.append("Original input archive is missing or changed.")
        original = ROOT / "original/calibration_reuse_followup"
        old = json.loads((original / "MANIFEST.json").read_text())
        failures.extend("Original: " + f for f in verify_map(original, old["sha256"]))
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(f"Verification could not complete: {exc}", file=sys.stderr)
        return 2
    if failures:
        print("FAIL\n" + "\n".join(failures))
        return 1
    extras = sorted(
        str(p.relative_to(ROOT)) for p in ROOT.rglob("*")
        if p.is_file() and p.name != "PACKAGE_MANIFEST.json"
        and str(p.relative_to(ROOT)) not in release["sha256"]
    )
    print(json.dumps({
        "status": "PASS",
        "release_file_hashes": len(release["sha256"]),
        "preserved_original_file_hashes": len(old["sha256"]),
        "original_archive_sha256": ORIGINAL_SHA256,
        "additional_untracked_files": extras,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
