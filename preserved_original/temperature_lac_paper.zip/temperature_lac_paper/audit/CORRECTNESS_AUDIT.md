# Correctness audit and theorem ledger

## Decision

The revised package supports a coherent standalone theory manuscript for expert review. No unresolved mathematical step is intentionally retained in its principal proofs. This is an independent rederivation within the same AI-assisted workflow, not independent human peer review or formal proof-assistant certification. Tests are not proofs of universal statements.

The paper now leads with a class-count-specific structural characterization and a **uniform finite-sample coverage-deficit characterization**, rather than with a correction. The original iterated limit is retained as a strictly weaker, separately proved statement.

## Common assumptions and quantities

- K is an integer at least two. Logits are finite and arise from a Borel classifier fixed independently of calibration; conditioning on independently trained logits is allowed.
- Calibration observations and a fresh test observation are iid. Merely exchangeable dependent calibration samples are not covered by the empirical-process theorem.
- One positive inverse temperature is chosen globally by a Borel rule of the calibration data. The upper bound permits any such rule; the lower construction uses a deliberately adverse normalized-cutoff rule.
- Scores are nonrandomized LAC, S=1-p_y. Ordinary score-threshold sets may be empty. No argmax supplementation, APS/RAPS, vector scaling, feature-dependent temperature, or joint model refitting is included.
- N=n+1; k is an integer in [1,N]; finite-rank reference coverage p=k/N. Nominal c uses k=ceil(Nc). If k=N, sets are full, and coverage is one. Beta(k,N-k) is used only for k<=n.
- Expected conditional shortfall E[(p-Cov(D))_+] is not marginal deficit [p-E Cov(D)]_+. Neither is automatically a difference of absolute coverage gaps.
- All log-K asymptotics vary the number of classes; the model family may depend on K but the realized classifier is fixed before, and independently of, the calibration sample.

## Audit table

| Claim | Verdict | Independent derivation or counterexample | Required repair | Effect on paper |
|---|---|---|---|---|
| Pi_K(m) <= min(2^m,m+1+(K-2)m(m-1)) | Verified | Inductively count distinct exponential zeros; reserve the zero at beta=0; insert graphs into the parameter plane | Explain all degeneracies and weak-threshold boundaries | Retained with full Appendix A proof |
| Positive pair crossings <=2K-4 | Verified | Difference contains at most 2(K-1) nonzero distinct exponential terms; identical functions handled separately | Do not conflate distinct-zero and multiplicity arguments | Retained |
| Curve arrangement counts every threshold pattern | Verified | Shift a weak cutoff slightly upward; finite excluded gaps allow an open-face representative | Explicitly treat full/empty patterns, tangencies, simultaneous crossings, coincident curves | Retained |
| K-1 independent local score coordinates inside one fixed softmax | Verified and generalized | Exponential evaluation Jacobian nonsingular at any distinct competitor gaps and any distinct positive temperatures; inverse-function theorem on an open image | State common delta depends on K, gaps and selected temperatures; no uniform radius | Works in any nonempty open temperature interval with bounded logits |
| d_K/log2 K ->1 | Verified and strengthened | Explicit growth upper; realization lower | None needed for original claim | New symmetric-chain lower b(K-1), b(M)=max{m: binom(m,floor m/2)<=M}; sharper second-order lower |
| K=2, d=1 | Verified | All scores strictly transform the same target/competitor gap | Separate marginal validity from random conditional coverage | Marginal deficit identically zero; conditional shortfall need not vanish |
| K=3, d=2 | Verified | log-cosh comparison gives at most one positive crossing; exact rational two-point witness | None | Retained |
| Original K=4 floating witness shatters three points | Rejected, as in prior exact audit | Exact rational values give seven of eight requested patterns | Preserve failed witness; do not reuse it | New and different Taylor-certified K=4 witness does shatter three points; exact d_4 still not claimed |
| E[(p-Cov(D))_+] <= C sqrt(log K/n) | Verified | Empirical acceptance >=k/n>=p; precise expected VC inequality; rational parameter approximation yields pointwise measurability | State iid, fixed model, measurable selector and metric; constant not operational | Retained at finite-rank reference p; nominal follows |
| Coverage=min of independent Beta(k,N-k) variables | Verified for k<=n | Product-uniform coordinate arrays; fixed-model score realization; selector observes normalized empirical cutoffs only | Missing k=N case repaired as full sets; independence explicitly justified | Exact finite law retained; boundary implementation repaired in new code |
| Same-data loss is an NLL failure | Rejected interpretation | NLL always chooses beta=2 in the explicit example and attains ordinary coverage | Keep negative control prominent | No NLL-specific adverse claim |
| Original iterated Gaussian maximum limit | Verified | Gamma-ratio CLT plus fixed-M L2 bound gives uniform integrability; Gaussian maximum bounds | Keep order of limits explicit | Retained as illustration, not used as a uniform theorem |
| Uniform finite-sample matching rate | New derivation completed | Beta density lower envelope; independent separated events; cancellation-free minimum identity; transfer through softmax realization | State p interior, N>=16/eta^2 and K>=3; cap the rate; nominal rounding cannot be dropped | Main strengthened theorem: uniform over K and n in stated regime |
| Fixed precision or class-independent separation | Not established | Local radius and certified score gaps can shrink sharply with K and interval width | No finite-bit claim | Explicit limitation |
| Failure for all calibration-reuse procedures | Rejected interpretation | Exact-valid post-selection/full-conformal alternatives change the procedure | Restrict lower claim to unmodified same-data LAC and worst selector | Existing valid-reuse methods remain alternatives |

## Structural quantifiers and boundary details

**Growth:** for every K>=2, every finite m and every list of m input-label/logit-label points. Coincident curves cannot separate coincident score functions. Exponential differences always vanish at zero, even if zero is outside the allowed open positive-temperature domain; it still uses one zero in the global zero-count theorem. Tangencies or coincident intersection locations only reduce possible faces relative to the pairwise count. The cutoff endpoints t=0 and t=1 yield full and empty patterns because logits are finite.

**Realization:** for every finite M=K-1, every prescribed M distinct positive inverse temperatures and every B>0, there exist a smooth logit map on a neighborhood of the entire cube, M fixed offsets and a common positive delta. The map has target logit zero and all competitor logits strictly between -B and zero. The construction is fixed independently of n, k, the random calibration draw and all test observations. It does not require boundedness or Lipschitzness uniform in K. The inverse Jacobian may be ill-conditioned; delta may be arbitrarily small.

**Refined lower bound:** a symmetric-chain partition is proved inductively, then each chain is extended to a full permutation. One realized temperature coordinate supplies each permutation's threshold prefixes. All middle-layer subsets require distinct chains; the construction uses binom(m,floor m/2) coordinates. This yields a sufficient condition for shattering, not an exact finite-K VC formula. In particular, K=4 supports three points and K=7 supports four; no exact value for d_4 or d_7 is asserted.

**Coverage upper:** measurability is established by rational beta perturbations of order j^-2 and a positive threshold slack of order j^-1, making weak inequalities converge pointwise. The expected VC empirical-process lemma is standard and its exact inequality is stated. A separately supplied explicit finite-trace bound is looser and contains log n; its constants are not combined with the sharp entropy rate.

**Coverage law:** the distribution is Uniform([0,1]^M), Y=1. Conditional on calibration the selected index is fixed and its fresh coordinate remains uniform. Every fixed temperature has exact reference coverage p. The selector minimizes a normalized threshold, not raw LAC thresholds or NLL. All true labels are the argmax; forcing the argmax into every set removes this example.

**Uniform lower:** for eta in (0,1/2], N>=16/eta^2, p=k/N in [eta,1-eta], all M>=2. A density lower envelope from explicit Stirling bounds produces constants r_eta and q_eta; on independent events B_1>=p and min_{2..M}B_r<=p-t, the nonnegative difference is >=t. Taking t=(eta/4)min(1,sqrt(log M/N)) works even for exponentially large M. The proof is uniform, not an exchanged limit. Constants depend only on eta; they are intentionally conservative and not useful numerical penalties.

**Nominal coverage:** p-c is nonnegative and strictly less than 1/N. The exact lower statement subtracts 1/N and takes its positive part. For an interior nominal range and sufficiently large n depending only on that range, rounding is absorbed and gives the same capped order uniformly in K. The main theorem avoids ambiguous rounding by stating its reference level p explicitly.

## Independent checks and reproduction

All supplied numerical outputs were rerun in `reproduction/package`, leaving the preserved package untouched. The original 15 tests pass. All 20 raw arrays match exactly, both CSVs match byte for byte, and the original exploratory search matches all structural output fields. Timing fields are not expected to match.

Twelve new named tests pass. Exact rational integration independently certifies the primary mean as 5214610247405709/5903643345897130. Ten finite chain partitions and two new Taylor certificates pass; the universal chain lemma is proved by induction, not by that enumeration. Forty-eight deterministic integrations illustrate the Beta law. The density-envelope numerical grid and these integrations are implementation checks, not evidence that substitutes for proof.

## Adversarial objections that remain relevant

The result is worst-case, adversarial-selector and real-arithmetic. It does not certify typical behavior of NLL tuning. The lower construction's perfectly correct argmax predictions make empty-set behavior central. Universal finite-rank rate constants are not operational. A specialized theorem can be correct but viewed as an application of known tools with insufficient venue-level significance. No external referee or proof assistant has checked the argument. The exact priority of the softmax-specific characterization remains the principal non-correctness uncertainty.

A singleton temperature range is a fixed-score problem and is outside the open-interval lower-bound assertion. Adding beta=0 would produce uniform class probabilities and full LAC sets at that particular temperature; all adaptive theorems here use beta>0. K=1 is excluded as a trivial one-label problem.
