# Build and visual layout report

Date: 2026-09-30.

## Delivered manuscript

`manuscript/main.pdf` contains 15 pages: eight pages of main text, a references page, and six pages of appendices. Source files are `main.tex`, `references.bib`, and the supplied matching `main.bbl`.

The document was built with pdfLaTeX. The first attempt using latexmk encountered the unavailable BibTeX executable. This is a build-environment limitation, not a successful BibTeX run. The verified reference entries were rendered explicitly into `main.bbl`; repeated pdfLaTeX passes then resolved all citations and cross-references. The delivered `build.sh` uses BibTeX when present and otherwise uses the supplied BBL. The script was tested successfully.

The final log contains no unresolved citations, unresolved cross-references, LaTeX warnings, or overfull boxes. A copy of the final log is preserved as `audit/latex_build.log`.

## Visual inspection

All pages were rendered with Poppler's `pdftoppm` at 110 dpi and visually inspected, including final revisions. Pairwise contact sheets were used alongside individual page renders. Inspected elements include the title and abstract, theorem displays, table alignment, references, appendix equations, page breaks, and page numbers. No clipped text, overlapping elements, missing glyphs, black boxes, or broken equations were found.

The final PDF was also checked programmatically for text coordinates: every word falls within the page's horizontal 25-point and vertical 20-point safety margins. The per-page results are in `pdf_text_bounds.json`. This coordinate test complements, rather than replaces, visual inspection.

Rendered inspection images and expendable TeX auxiliary files are not included in the release. The final PDF, editable sources, BBL, build script and audit log are included. No font files are distributed.

## Scope

Visual inspection verifies presentation, not mathematical correctness or originality. Those questions are documented separately in the correctness and novelty audits. The manuscript has not been submitted and no human authorship or venue-specific approval is implied.
