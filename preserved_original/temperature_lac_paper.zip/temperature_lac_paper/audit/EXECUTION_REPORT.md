# Execution and evidence report

## Completed work

The attached archive was hashed, copied and extracted without alteration. The proof, evidence, prior-work, code and result files were inspected. Each central argument was independently rederived before being relied upon. The main repaired and strengthened results are written with full proofs in the manuscript, not left as proposed claims.

The original exploratory search, exact integer audit, interpolation certificates, coverage study and 15 tests were rerun separately. The research runner was then exercised end to end in another fresh directory as a usability check.

## Reproduction results

- Original manifest: **32 protected file hashes pass**.
- Original tests: **15 pass**.
- Original main CSV: **byte-for-byte match**.
- Original 15-cell diagnostic CSV: **byte-for-byte match**.
- Saved raw arrays: **20/20 exactly equal** (five main arrays and fifteen direct-Beta diagnostic arrays).
- Exploratory search: result entries, rational temperature nodes, node denominator and seed **all match**. The old floating-point four-class witness again suggests eight patterns and again fails exact verification; this is retained, not repaired by relabeling the old witness.
- Clean execution of `code/reproduce.py`: **PASS**, with its comparison log copied into the audit records.

## New checks

`code/audit_checks.py` has **12 named tests**, all passing. The primary mean is certified by exact rational polynomial integration:

`5214610247405709 / 5903643345897130 = 0.8832868013664341...`

Independent numerical quadrature differs by 2.22e-16. A rational K=3 crossing witness, full-set boundaries, exact quantile indexing and the explicit softmax algebra were checked. A finite density-envelope grid checks the implemented constants; it is not the universal proof. The fixed 48-cell integration grid is a deterministic numerical illustration, not additional Monte Carlo or real-data evidence.

`code/chain_certificate.py` verifies ten finite symmetric-chain decompositions and two new witnesses. K=4 certifies eight patterns on three points, and K=7 certifies sixteen on four. The certificate consists of exact rational linear identities and a proved Taylor remainder <=1/8 of an adjacent rank step per curve. High-precision exponentials supply secondary corroboration. No exact claim for d_4 or d_7 is made.

## Reproduced primary coverage

10,000 iid calibration experiments; n=99, k=90; nominal coverage 90%. Conditional fresh-test coverage is integrated analytically for each computed model/threshold, rather than approximated using a finite test set.

| Procedure | Observations | Expected coverage | Measured coverage | 95% Monte Carlo interval |
|---|---:|---:|---:|---:|
| Adversarial same-data reuse | 99 | 0.8832868013664341 | 0.8828480197653218 | [0.8823127117202834, 0.8833833278103602] |
| Fixed temperature | 99 | 0.9 | 0.8994795393474396 | [0.8988959934555170, 0.9000630852393623] |
| Independent tuning/calibration | 198 | 0.9 | 0.9004741031452453 | [0.8998886708529233, 0.9010595354375673] |
| Same-total-data split (50/49) | 99 | 0.9 | 0.8994111466243192 | [0.8985802471135207, 0.9002420461351177] |
| NLL grid control | 99 | 0.9 | 0.8999654023921808 | [0.8993770170798611, 0.9005537877045006] |

The paired independent-minus-reuse estimate is 0.01762608338; its theoretical value is 0.01671319863 and the discrepancy is 2.2607 Monte Carlo standard errors. Its nominal 95% interval does not contain the theoretical value. The seed and endpoint were preserved. The original diagnostic tolerance was not changed to make this interval look better.

The NLL control is non-failing. All true labels are already unique argmax predictions, and NLL chooses the larger inverse temperature. An argmax-supplemented LAC rule also removes this construction's coverage failure.

## Hardware, versions and actual resource use

- CPU reported by the container: AMD EPYC 9V74 80-Core Processor; five logical CPUs visible. This is not a laptop timing measurement.
- Linux 6.18.44 x86_64; Python 3.13.5.
- NumPy 2.3.5; SciPy 1.17.0; SymPy 1.14.0; mpmath 1.3.0.
- OMP, OpenBLAS and MKL thread counts fixed to one for numerical commands.
- Eight instrumented research commands: **30.79 CPU seconds total**; **152.03125 MiB peak recorded RSS**.
- The standalone rerun of the original main coverage study and its original diagnostics: **2.60 CPU seconds**, **150.25 MiB peak RSS**.
- The new independent audit: **2.58 CPU seconds**. New chain certificates: **1.17 CPU seconds**.
- The clean end-to-end runner, which deliberately repeats work as an execution check: **15.54 CPU seconds**, already included in the 30.79-second total.

These external `/usr/bin/time -v` measurements include interpreter startup for each command. Literature retrieval, mathematical reasoning, file inspection, writing, rendering, packaging and uninstrumented setup are not timed as numerical experiments. There were no GPU, model-training, paid model-API, or newly provisioned cloud-compute calls.

The original coverage seed is 2026093001 and the direct-Beta diagnostic seed is 2026093002. The original search seed is preserved in its protocol. New checks are deterministic and introduce no random seed or new Monte Carlo endpoint.

## Consequential choices and deviations

The original protocols and seeds were not changed. The new uniform finite-sample proof was developed analytically before numerical checking. New deterministic checks were declared in `extension_protocol.json` before their execution; the subsequent symmetric-chain refinement was separately recorded before its certificate execution. These local files are not independently timestamped preregistrations.

The original coverage helper's k=n+1 boundary was not silently edited. New generic code handles the boundary explicitly, and the manuscript qualifies the Beta theorem. The original n=99 results were unaffected by this boundary omission.

No practical NLL theorem, real-data experiment or new selection algorithm was added. No source claiming a specialized overlap was identified, but accessible correction-discussion coverage and broad search completeness are limited. See the novelty audit.

BibTeX was absent. A matching bibliography file was rendered explicitly from the supplied verified entries and compiled with `pdflatex`. This affects the build path, not the mathematics or references. A reusable build script handles either case.
