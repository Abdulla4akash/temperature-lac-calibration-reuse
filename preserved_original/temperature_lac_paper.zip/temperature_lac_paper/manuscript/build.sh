#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
pdflatex -interaction=nonstopmode -halt-on-error main.tex
if command -v bibtex >/dev/null 2>&1; then
  bibtex main
elif [ ! -f main.bbl ]; then
  echo 'BibTeX is unavailable and the supplied main.bbl is missing.' >&2
  exit 1
else
  echo 'BibTeX unavailable: using the supplied bibliography rendered from references.bib.'
fi
pdflatex -interaction=nonstopmode -halt-on-error main.tex
pdflatex -interaction=nonstopmode -halt-on-error main.tex
